import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChefHat, Utensils, Clock, Flame, Plus, X, Sparkles, Loader2, Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { suggestEgyptianRecipe, Recipe } from "@/lib/gemini";

export default function App() {
  const [ingredients, setIngredients] = useState<string[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [recipe, setRecipe] = useState<Recipe | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const addIngredient = () => {
    if (inputValue.trim() && !ingredients.includes(inputValue.trim())) {
      setIngredients([...ingredients, inputValue.trim()]);
      setInputValue("");
    }
  };

  const removeIngredient = (index: number) => {
    setIngredients(ingredients.filter((_, i) => i !== index));
  };

  const handleGenerate = async () => {
    if (ingredients.length === 0) return;
    setLoading(true);
    setError(null);
    try {
      const result = await suggestEgyptianRecipe(ingredients);
      setRecipe(result);
    } catch (err) {
      console.error(err);
      setError("حصلت مشكلة واحنا بنجيب الوصفة. جرب تاني كمان شوية.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] min-h-[calc(100vh-24px)]">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="top-part">
          <div className="logo">
            مطبخ<br />المحروسة
          </div>
          
          <div className="search-section space-y-6">
            <h2 className="text-xs uppercase tracking-[2px] opacity-60 font-bold">
              ماذا يوجد في خزانتك؟
            </h2>
            
            <div className="space-y-4">
              <div className="relative">
                <Input
                  placeholder="طماطم، أرز، عدس..."
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && addIngredient()}
                  className="border-none bg-transparent p-0 text-xl focus-visible:ring-0 placeholder:text-black/20"
                />
                <div className="h-[2px] bg-brand-ink w-full mt-1" />
                <Button 
                  size="icon" 
                  variant="ghost" 
                  onClick={addIngredient}
                  className="absolute left-0 top-0 text-brand-accent hover:bg-transparent"
                >
                  <Plus size={20} />
                </Button>
              </div>

              <div className="flex flex-wrap gap-2 min-h-[40px]">
                <AnimatePresence>
                  {ingredients.map((ing, index) => (
                    <motion.div
                      key={ing}
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.8, opacity: 0 }}
                    >
                      <Badge className="tag flex items-center gap-1">
                        {ing}
                        <X
                          size={12}
                          className="cursor-pointer hover:text-brand-accent"
                          onClick={() => removeIngredient(index)}
                        />
                      </Badge>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </div>

            <Button
              onClick={handleGenerate}
              disabled={ingredients.length === 0 || loading}
              className="w-full h-12 text-sm uppercase tracking-widest font-bold bg-brand-accent hover:bg-brand-accent/90 text-white rounded-none shadow-none transition-all disabled:opacity-30"
            >
              {loading ? (
                <Loader2 className="animate-spin" />
              ) : (
                "اقترح عليا أكلة"
              )}
            </Button>
          </div>
        </div>

        <div className="bottom-part mt-10">
          <p className="text-[13px] leading-relaxed opacity-70">
            اكتشف أسرار المطبخ المصري الأصيل من خلال مكوناتك البسيطة المتوفرة في المنزل.
          </p>
        </div>
      </aside>

      {/* Main Content */}
      <main className="p-8 md:p-16 relative overflow-y-auto">
        <div className="accent-circle" />
        
        <AnimatePresence mode="wait">
          {!recipe && !loading && !error && (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }}
              className="h-full flex flex-col items-center justify-center text-center space-y-6"
            >
              <ChefHat size={80} className="text-brand-accent opacity-20" />
              <h2 className="text-4xl font-serif opacity-40">في انتظار مكوناتك...</h2>
            </motion.div>
          )}

          {loading && (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }}
              className="h-full flex flex-col items-center justify-center text-center space-y-6"
            >
              <div className="w-20 h-20 border-4 border-brand-accent border-t-transparent rounded-full animate-spin" />
              <h2 className="text-3xl font-serif text-brand-accent">بنشوفلك أكلة حلوة...</h2>
            </motion.div>
          )}

          {error && (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }}
              className="h-full flex flex-col items-center justify-center text-center space-y-4"
            >
              <div className="p-6 bg-red-50 text-red-600 rounded-none border border-red-200 font-bold">
                {error}
              </div>
              <Button variant="link" onClick={handleGenerate} className="text-brand-accent">جرب تاني</Button>
            </motion.div>
          )}

          {recipe && !loading && (
            <motion.div
              key={recipe.name}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-12"
            >
              <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
                <h1 className="recipe-title-large">
                  {recipe.name.split(' ').map((word, i) => (
                    <span key={i} className="block">{word}</span>
                  ))}
                </h1>
                <div className="text-left md:text-right text-[13px] leading-relaxed font-bold uppercase tracking-wider opacity-80">
                  <div>الوقت: {recipe.cookingTime}</div>
                  <div>الصعوبة: {recipe.difficulty}</div>
                  <div className="text-brand-accent mt-2">مقترح المحروسة</div>
                </div>
              </header>

              <div className="grid md:grid-cols-2 gap-16">
                <div className="space-y-8">
                  <div className="space-y-4">
                    <h3 className="text-xs uppercase tracking-[3px] font-bold opacity-50">عن الأكلة</h3>
                    <p className="text-lg leading-relaxed italic opacity-80">
                      {recipe.description}
                    </p>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-xs uppercase tracking-[3px] font-bold opacity-50">المكونات</h3>
                    <ul className="space-y-3">
                      {recipe.ingredients.map((ing, i) => (
                        <li key={i} className="flex items-center gap-3 text-sm font-bold">
                          <span className="w-1.5 h-1.5 bg-brand-accent rounded-full" />
                          {ing}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="border-r border-brand-accent/20 pr-8 space-y-8">
                  <h3 className="text-xs uppercase tracking-[3px] font-bold opacity-50">طريقة التحضير</h3>
                  <div className="space-y-8">
                    {recipe.instructions.map((step, i) => (
                      <div key={i} className="space-y-2">
                        <span className="step-num-serif">
                          {String(i + 1).padStart(2, '0')}
                        </span>
                        <p className="text-[15px] leading-relaxed opacity-80">
                          {step}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <footer className="footer-nav-border">
                <div>٢٠٢٤ &copy; مطبخ المحروسة</div>
                <div className="flex gap-6">
                  <button onClick={() => window.print()} className="hover:text-brand-accent flex items-center gap-1">
                    <Printer size={12} /> طباعة الوصفة
                  </button>
                  <span className="opacity-30">|</span>
                  <span>الأطباق الأكثر شهرة</span>
                </div>
              </footer>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}

