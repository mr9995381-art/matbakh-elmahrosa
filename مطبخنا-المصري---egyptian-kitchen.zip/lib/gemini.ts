import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface Recipe {
  name: string;
  ingredients: string[];
  instructions: string[];
  cookingTime: string;
  difficulty: "سهل" | "متوسط" | "صعب";
  description: string;
}

export async function suggestEgyptianRecipe(ingredients: string[]): Promise<Recipe> {
  const prompt = `أنا عندي المكونات دي: ${ingredients.join(", ")}. 
  اقترح عليّ أكلة مصرية أصيلة ومشهورة ممكن أعملها بالمكونات دي أو بزيادة حاجات بسيطة عليها.
  لازم تكون الأكلة مصرية 100%.
  رجع النتيجة بصيغة JSON.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      systemInstruction: "أنت شيف مصري خبير في الأكلات الشعبية والتقليدية المصرية. هدفك هو مساعدة المستخدمين في طبخ أكلات مصرية أصيلة بناءً على المكونات المتوفرة لديهم. رد دائماً باللغة العربية المصرية العامية الودودة.",
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING, description: "اسم الأكلة المصرية" },
          ingredients: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING },
            description: "قائمة المكونات المطلوبة"
          },
          instructions: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING },
            description: "خطوات التحضير بالتفصيل"
          },
          cookingTime: { type: Type.STRING, description: "وقت الطبخ المتوقع" },
          difficulty: { 
            type: Type.STRING, 
            enum: ["سهل", "متوسط", "صعب"],
            description: "درجة الصعوبة"
          },
          description: { type: Type.STRING, description: "وصف قصير ومشوق للأكلة وتاريخها البسيط" }
        },
        required: ["name", "ingredients", "instructions", "cookingTime", "difficulty", "description"]
      }
    }
  });

  return JSON.parse(response.text);
}
